function onPaymentUpdate(data, code) {
  // console.log(code, data.payment.id)
  if (data.payment.id && data.passthrough) {
    let passthrough = JSON.parse(data.passthrough)
    jQuery.ajax({
      method: 'POST',
      url: '/?wc-api=WC_Cryptochill_Gateway',
      data: JSON.stringify(
          {action: 'update_invoice', invoice_id: data.payment.id, order_id: passthrough.order_id}),
    }).done(function() {
      // console.log('invoice updated')
    })
  }
}

function onPaymentOpen(data, code) {
  console.log(code, data)
}

function onPaymentSuccess(data, code) {
  console.log(code, data.payment)
  if ((data.payment.payment_status === 'paid' || data.payment.payment_status === 'processing') &&
      data.passthrough) {
    let passthrough = JSON.parse(data.passthrough)
    window.location.replace(passthrough.return_url)
  }

}

function onPaymentCancel(data, code) {
  console.log(code, data)
}

jQuery(function($) {
  if (!merchant_params) return
  // $merchant_site_url = "https://cryptochill.com/";

  SDK.setup({
    account: merchant_params.account,
    profile: merchant_params.profile,
    passthrough: JSON.stringify(merchant_params.passthrough),
    devMode: true,
    apiEndpoint: 'https://cryptochill.com/',
    onOpen: onPaymentOpen,
    onSuccess: onPaymentSuccess,
    onUpdate: onPaymentUpdate,
    onCancel: onPaymentCancel,
  })

})

var merchant_params = {
  'account': 'e2267df6-1957-4fef-804c-8f8890ae5b28',
  'profile': '1e44e7f0-927c-4f0a-824e-64e1008993f6',
  'passthrough': {
    'order_id': 13388,
    'order_key': 'wc_order_gUW8UWqbG50TU',
    'description': '1 x 25,000 USD Evaluation',
    'return_url': 'https:\/\/elitesfunding.com\/register\/order-received\/13388\/?key=wc_order_gUW8UWqbG50TU',
    'source': 'woocommerce',
  },
}
