<?php
	/*
	Plugin Name:  Cryptochill Payment Gateway
	Plugin URI:   https://cryptochill.com/
	Description:  A payment gateway that allows your customers to pay with cryptocurrency
	Version:      0.0.4
	Author:       Cryptochill
	License:      GPLv3+
	License URI:  https://www.gnu.org/licenses/gpl-3.0.html
	Text Domain:  merchant
	Domain Path:  /languages
	Requires Plugins: woocommerce

	WC requires at least: 3.0.9
	WC tested up to: 3.6.3

	Cryptochill is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	any later version.

	Cryptochill is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with Cryptochill WooCommerce. If not, see https://www.gnu.org/licenses/gpl-3.0.html.
	*/
	define('SUPPORTED_MERCHANT_CURRENCIES', [
		'USD',
		'EUR',
		'GBP',
		'AUD',
		'CHF',
	]);


	function merchant_init_gateway(){
		// If WooCommerce is available, initialise WC parts.
//		$site_plugins    = apply_filters( 'active_plugins', get_option( 'active_plugins' ) );
//    $network_plugins = get_network_option( 'active_sitewide_plugins', array() );

		if (class_exists( 'WooCommerce')) {
			require_once 'class-wc-merchant-gateway.php';
			add_action('init', 'merchant_wc_register_blockchain_status');
			add_action('init', 'merchant_wc_check_currency_support');
			add_filter('woocommerce_valid_order_statuses_for_payment', 'merchant_wc_status_valid_for_payment', 10, 2);
			add_action('merchant_check_orders', 'merchant_wc_check_orders');
			add_filter('woocommerce_payment_gateways', 'merchant_wc_add_merchant_class');
			add_filter('wc_order_statuses', 'merchant_wc_add_status');
			add_action('woocommerce_admin_order_data_after_order_details', 'merchant_order_meta_general');
			add_action('woocommerce_order_details_after_order_table', 'merchant_order_meta_general');
			add_filter('woocommerce_email_order_meta_fields', 'merchant_custom_woocommerce_email_order_meta_fields', 10, 3);
		}
	}

	add_action('plugins_loaded', 'merchant_init_gateway');


	// Setup cron job.


	function cron_add_minute($schedules){
		// Adds once every 5 minutes to the existing schedules.
		$schedules['every_5_minutes'] = array(
			'interval' => 60 * 5,
			'display'  => __('Once Every 5 Minutes')
		);

		return $schedules;
	}

	add_filter('cron_schedules', 'cron_add_minute');

	function merchant_activation(){

        if (!class_exists( 'WooCommerce')) {
            $message = __('WooCommerce is not installed!', 'merchant');
//            wp_die($message);
            return;
        }

		if(!in_array(get_woocommerce_currency(), SUPPORTED_MERCHANT_CURRENCIES)){
			deactivate_plugins(plugin_basename(__FILE__));
			$message = sprintf(__('Your shop currency (%s) is not supported by Cryptochill!  Sorry about that.', 'merchant'), get_woocommerce_currency());
			wp_die($message);
		}

		if(!wp_next_scheduled('merchant_check_orders')){
			wp_schedule_event(time(), 'every_minute', 'merchant_check_orders');
		}
	}

	register_activation_hook(__FILE__, 'merchant_activation');

	function merchant_deactivation(){
		wp_clear_scheduled_hook('merchant_check_orders');
	}

	register_deactivation_hook(__FILE__, 'merchant_deactivation');

    if ( ! defined( 'CHECK_PLUGIN_DEPENDENCIES_PLUGIN_FILE' ) ) {
        /**
         * Path to the plugin's main file.
         *
         * Stores the path to the plugin's main file as a constant so we can refer to this file
         * or the plugin's root directory later using `dirname( CHECK_PLUGIN_DEPENDENCIES_PLUGIN_FILE )`.
         *
         * @var string
         */
        define( 'CHECK_PLUGIN_DEPENDENCIES_PLUGIN_FILE', __FILE__ );
    }

    // Do not setup the plugin if a setup class with the same name was already defined.
    if ( ! class_exists( 'Check_Plugin_Dependencies\Check_Plugin_Dependencies' ) ) {
        /**
         * The file where the Autoloader class is defined.
         */
        require_once __DIR__ . '/includes/Autoloader.php';
        spl_autoload_register( array( new \Check_Plugin_Dependencies\Autoloader(), 'autoload' ) );
        $check_plugin_dependencies = new \Check_Plugin_Dependencies\Check_Plugin_Dependencies();
        $check_plugin_dependencies->setup();
    }




	// WooCommerce

	function merchant_wc_add_merchant_class($gateways){
		$gateways[] = 'WC_Cryptochill_Gateway';

		return $gateways;
	}

	function merchant_wc_check_orders(){
		$gateway = WC()->payment_gateways()->payment_gateways()['merchant'];

		return $gateway->check_orders();
	}

	function currency_admin_notice__error(){
		$class   = 'notice notice-error';
		$message = sprintf(__('Your shop currency (%s) is not supported bu Cryptochill!', 'merchant'), get_woocommerce_currency());
		printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
	}

	function merchant_wc_check_currency_support(){
		if(!in_array(get_woocommerce_currency(), SUPPORTED_MERCHANT_CURRENCIES)){
			add_action('admin_notices', 'currency_admin_notice__error');
		}
	}


	/**
	 * Register new status with ID "wc-blockchainpending" and label "Cryptochill Pending"
	 */
	function merchant_wc_register_blockchain_status(){
		register_post_status('wc-blockchainpending', array(
			'label'                     => __('Blockchain Pending', 'merchant'),
			'public'                    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop('Blockchain pending <span class="count">(%s)</span>', 'Blockchain pending <span class="count">(%s)</span>'),
		));
	}

	/**
	 * Register wc-blockchainpending status as valid for payment.
	 */
	function merchant_wc_status_valid_for_payment($statuses, $order){
		$statuses[] = 'wc-blockchainpending';

		return $statuses;
	}

	/**
	 * Add registered status to list of WC Order statuses
	 *
	 * @param array $wc_statuses_arr Array of all order statuses on the website.
	 *
	 * @return array
	 */
	function merchant_wc_add_status($wc_statuses_arr){
		$new_statuses_arr = array();

		// Add new order status after payment pending.
		foreach($wc_statuses_arr as $id => $label){
			$new_statuses_arr[$id] = $label;

			if('wc-pending' === $id){  // after "Payment Pending" status.
				$new_statuses_arr['wc-blockchainpending'] = __('Blockchain Pending', 'merchant');
			}
		}

		return $new_statuses_arr;
	}


	/**
	 * Add order Cryptochill meta after General and before Billing
	 *
	 * @param WC_Order $order WC order instance
	 */
	function merchant_order_meta_general($order){
		if($order->get_payment_method() == 'merchant'){

            if(!defined( 'MERCHANT_SITE_URL' )){
				die('No environment configured MERCHANT_SITE_URL');
			}
			?>
			<br class="clear"/>
			<h2>Payment Data</h2>
			<div class="">
				<p>Cryptochill Payment ID:
					<a target="_blank" href="<?php echo MERCHANT_SITE_URL; ?>public/payment/<?php echo esc_html($order->get_meta('_merchant_payment_id')); ?>/"><?php echo esc_html($order->get_meta('_merchant_payment_id')); ?></a>
				</p>
			</div>
			<?php
		}
	}


	/**
	 * Add Cryptochill meta to WC emails
	 *
	 * @param array $fields indexed list of existing additional fields.
	 * @param bool $sent_to_admin If should sent to admin.
	 * @param WC_Order $order WC order instance
	 *
	 * @return array
	 */
	function merchant_custom_woocommerce_email_order_meta_fields($fields, $sent_to_admin, $order){
		if($order->get_payment_method() == 'merchant'){
			$fields['merchant_commerce_reference'] = array(
				'label' => __('Cryptochill Payment ID #'),
				'value' => $order->get_meta('_merchant_payment_id'),
			);
		}

		return $fields;
	}
